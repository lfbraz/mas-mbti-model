# mas-mbti-model
This repo is used to control the multi-agent-system model to simulate the interactions between the agents with different type of personallities.

.\gama-headless.bat MBTI-Low.xml output\

.\gama-headless.bat .\MBTI-Low.xml output_mbti_low\